# CSV Upload Test Files

This directory contains test files to validate the bank statement CSV upload functionality and error handling.

## Valid Test Files ✅

### `valid-bank-statement.csv`
- **Purpose**: Test basic valid CSV format
- **Expected Result**: Should upload successfully
- **Contains**: Standard YYYY-MM-DD dates, decimal amounts

### `valid-different-formats.csv`
- **Purpose**: Test various valid date and amount formats
- **Expected Result**: Should upload successfully with format conversion
- **Contains**: 
  - Date formats: MM/DD/YYYY, MM-DD-YYYY, M/D/YYYY
  - Amount formats: $111.00, "$1,116.50", 104, 85.5

### `valid-recent-transactions.csv`
- **Purpose**: Test with real transaction data that should match existing ledger entries
- **Expected Result**: Should upload successfully and show matches
- **Contains**: Exact matches for recent Starbucks, Office Depot, Amazon, Company, and Whole Foods transactions

### `valid-mixed-formats.csv`
- **Purpose**: Test mixed date/amount formats with some existing and some new transactions
- **Expected Result**: Should upload successfully with format conversion and partial matches
- **Contains**: 
  - Mix of existing invoice numbers and new ones
  - Various date formats (MM/DD/YYYY, MM-DD-YYYY, YYYY-MM-DD)
  - Currency symbols and decimal variations

### `valid-partial-matches.csv`
- **Purpose**: Test scenario with some matches and some bank-only entries
- **Expected Result**: Should upload successfully showing mixed source types
- **Contains**: 
  - One exact match (INV-1754015194549-321)
  - Several bank-only transactions that won't match existing emails

## Invalid Test Files ❌

### `invalid-dates-amounts.csv`
- **Purpose**: Test date and amount validation errors
- **Expected Errors**:
  - Row 1: "invalid-date" → Invalid date format error
  - Row 2: "2025-13-45" → Invalid date (month 13)
  - Row 3: "99/99/9999" → Invalid date
  - Row 4: "not-a-number" → Invalid amount format
  - Row 5: "abc123" → Invalid amount format

### `missing-required-fields.csv`
- **Purpose**: Test required field validation
- **Expected Errors**:
  - Row 1: Missing Invoice Number
  - Row 2: Missing Date
  - Row 3: Missing Amount
  - Row 4: Missing Amount
  - Row 5: Missing Date and Amount

### `edge-cases.csv`
- **Purpose**: Test boundary conditions and edge cases
- **Expected Errors**:
  - Row 1: Date 1850-01-01 → Year too old (before 1900)
  - Row 2: Date 2050-12-31 → Year too far in future
  - Row 3: Amount 2000000.00 → Amount too large (over $1M limit)
  - Row 4: Amount -2000000.00 → Amount too negative (under -$1M limit)
  - Row 5: Amount 123.456789 → Should round to 2 decimal places (might pass)

### `wrong-columns.csv`
- **Purpose**: Test column header validation
- **Expected Error**: Missing required columns (Invoice Number, Date, Amount)

### `empty-file.csv`
- **Purpose**: Test empty file handling
- **Expected Error**: "CSV file is empty"

## How to Test

1. Navigate to the application
2. Go to the Ledger page
3. Use the Bank Statement Upload component
4. Upload each test file and verify the expected behavior:
   - Valid files should upload successfully
   - Invalid files should show specific error messages

## Expected Validation Features

- **Date Validation**: Multiple formats accepted, reasonable year range
- **Amount Validation**: Currency symbols stripped, decimal precision, range limits
- **Required Fields**: All three columns must have values
- **Error Messages**: Row-specific errors with clear descriptions
- **File Format**: Must be .csv with correct headers
